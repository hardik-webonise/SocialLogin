package br.com.condesales.models;


public class Venues {
	
	private Venue venue;
	
	private int beenHere;

	public Venue getVenue() {
		return venue;
	}

	public int getBeenHere() {
		return beenHere;
	}

}
