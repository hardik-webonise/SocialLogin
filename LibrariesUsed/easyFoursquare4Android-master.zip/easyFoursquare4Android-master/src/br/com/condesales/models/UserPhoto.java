package br.com.condesales.models;

public class UserPhoto {

	private String prefix;
	private String suffix;

	public String getPrefix() {
		return prefix;
	}

	public String getSuffix() {
		return suffix;
	}

}
