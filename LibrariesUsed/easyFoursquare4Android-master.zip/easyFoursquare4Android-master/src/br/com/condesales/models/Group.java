package br.com.condesales.models;

import java.io.Serializable;

public class Group implements Serializable {

	private static final long serialVersionUID = 3667889421203126061L;

	public Venue[] items;
	
}
