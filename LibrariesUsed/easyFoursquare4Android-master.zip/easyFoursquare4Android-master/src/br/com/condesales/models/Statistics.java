package br.com.condesales.models;

public class Statistics {

	public int getCheckinsCount() {
		return checkinsCount;
	}

	public int getUsersCount() {
		return usersCount;
	}

	public int getTipCount() {
		return tipCount;
	}

	private int checkinsCount;

	private int usersCount;

	private int tipCount;
}
