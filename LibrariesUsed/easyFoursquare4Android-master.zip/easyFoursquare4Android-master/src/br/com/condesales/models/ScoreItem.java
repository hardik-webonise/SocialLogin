package br.com.condesales.models;

public class ScoreItem {

	private String message;

	private String icon;

	private int points;

	public String getMessage() {
		return message;
	}

	public String getIcon() {
		return icon;
	}

	public int getPoints() {
		return points;
	}

}
