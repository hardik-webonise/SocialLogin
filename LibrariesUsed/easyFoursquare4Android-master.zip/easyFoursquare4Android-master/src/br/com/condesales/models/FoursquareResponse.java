package br.com.condesales.models;

import java.io.Serializable;

public class FoursquareResponse implements Serializable {

	private static final long serialVersionUID = -383365244692781213L;

	public Response response;
	
}
