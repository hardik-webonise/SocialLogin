package br.com.condesales.models;

import java.io.Serializable;

public class Response  implements Serializable {

	private static final long serialVersionUID = -8744243204974447941L;

	public Group[] groups;
	
}
