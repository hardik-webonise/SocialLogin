package br.com.condesales.models;

public class Mayor {
	private int count;
	
	private User user;

	public int getCount() {
		return count;
	}

	public User getUser() {
		return user;
	}
	
}
