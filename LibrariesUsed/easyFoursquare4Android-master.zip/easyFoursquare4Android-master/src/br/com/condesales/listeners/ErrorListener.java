package br.com.condesales.listeners;

public interface ErrorListener {
	
	public void onError(String errorMsg);

}
